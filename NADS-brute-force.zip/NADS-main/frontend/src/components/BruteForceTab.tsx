import { useState } from 'react';
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts';
import { useBruteForce } from '../hooks/useBruteForce';

export function BruteForceTab() {
  const { byService, rates, rotations, offenders, timeline, blocked, blockIP, unblockIP } = useBruteForce();
  const [manualIp, setManualIp] = useState('');
  const [reason, setReason] = useState('');

  const services: { key: keyof typeof byService; label: string; color: string }[] = [
    { key: 'SSH',      label: 'SSH',      color: '#ef4444' },
    { key: 'FTP',      label: 'FTP',      color: '#f97316' },
    { key: 'RDP',      label: 'RDP',      color: '#eab308' },
    { key: 'Telnet',   label: 'Telnet',   color: '#a78bfa' },
    { key: 'HTTP',     label: 'HTTP',     color: '#38bdf8' },
    { key: 'Spraying', label: 'Spraying', color: '#f472b6' },
  ];

  const handleManualBlock = async () => {
    if (!manualIp.trim()) return;
    await blockIP(manualIp.trim(), reason || 'Manual block');
    setManualIp('');
    setReason('');
  };

  const totalAttempts = timeline.reduce(
    (s, p) => s + p.SSH + p.FTP + p.RDP + p.Telnet + p.HTTP + p.Spraying, 0
  );

  const chartData = timeline.map((p) => ({
    t: new Date(p.ts * 1000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    Total: p.SSH + p.FTP + p.RDP + p.Telnet + p.HTTP + p.Spraying,
  }));

  return (
    <div>
      {/* KPI ROW — 6 services */}
      <div className="kpis" style={{ gridTemplateColumns: 'repeat(6, 1fr)' }}>
        {services.map((s) => (
          <div className="kpi" key={s.key}>
            <div className="label">{s.label} Brute Force</div>
            <div className="value" style={{ color: s.color }}>
              {byService ? byService[s.key] : 0}
            </div>
            <div className="sub">last hour</div>
          </div>
        ))}
      </div>

      {/* TIMELINE — single red wave (matches his TrafficChart style) */}
      <div className="card" style={{ marginBottom: 12 }}>
        <h3>📈 Brute Force Timeline — {totalAttempts} attempts</h3>
        <ResponsiveContainer width="100%" height={220}>
          <AreaChart data={chartData}>
            <defs>
              <linearGradient id="bfTotal" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#ef4444" stopOpacity={0.6} />
                <stop offset="100%" stopColor="#ef4444" stopOpacity={0.05} />
              </linearGradient>
            </defs>
            <CartesianGrid stroke="#16203a" strokeDasharray="3 3" />
            <XAxis dataKey="t" tick={{ fill: '#8b98b4', fontSize: 11 }} minTickGap={30} />
            <YAxis tick={{ fill: '#8b98b4', fontSize: 11 }} allowDecimals={false} />
            <Tooltip contentStyle={{ background: '#0b1220', border: '1px solid #1e2a45' }} />
            <Area
              type="monotone"
              dataKey="Total"
              stroke="#ef4444"
              strokeWidth={2}
              fill="url(#bfTotal)"
            />
          </AreaChart>
        </ResponsiveContainer>
      </div>

      {/* RATES + VPN ROTATION */}
      <div className="grid2">
        <div className="card">
          <h3>⚡ Live Rate Per IP (60s window)</h3>
          <table className="talkers">
            <thead>
              <tr><th>IP</th><th>Attempts</th><th>Rate/s</th><th>Action</th></tr>
            </thead>
            <tbody>
              {rates.length === 0 && (
                <tr><td colSpan={4} style={{ color: '#8b98b4' }}>No active attackers.</td></tr>
              )}
              {rates.map((r) => (
                <tr key={r.ip}>
                  <td style={{ fontFamily: 'monospace' }}>{r.ip}</td>
                  <td style={{ color: '#ef4444', fontWeight: 700 }}>{r.attempts}</td>
                  <td>{r.rate_per_sec}</td>
                  <td>
                    <button
                      onClick={() => blockIP(r.ip, 'High brute force rate')}
                      style={{ background: '#7f1d1d', color: '#fca5a5', border: '1px solid #ef4444', borderRadius: 6, padding: '3px 10px', cursor: 'pointer', fontSize: 12 }}
                    >
                      Block
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="card">
          <h3>🕵️ VPN / IP Rotation</h3>
          <table className="talkers">
            <thead>
              <tr><th>Username</th><th>Unique IPs</th><th>Attempts</th></tr>
            </thead>
            <tbody>
              {rotations.length === 0 && (
                <tr><td colSpan={3} style={{ color: '#8b98b4' }}>No rotation detected.</td></tr>
              )}
              {rotations.map((v) => (
                <tr key={v.username}>
                  <td>{v.username}</td>
                  <td style={{ color: '#eab308', fontWeight: 700 }}>{v.unique_ips}</td>
                  <td>{v.total_attempts}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* TOP OFFENDERS */}
      <div className="card" style={{ marginTop: 12 }}>
        <h3>🎯 Top Offenders</h3>
        <table className="talkers">
          <thead>
            <tr><th>IP</th><th>Attempts</th><th>Services</th><th>Last Seen</th><th>Action</th></tr>
          </thead>
          <tbody>
            {offenders.length === 0 && (
              <tr><td colSpan={5} style={{ color: '#8b98b4' }}>No offenders yet.</td></tr>
            )}
            {offenders.slice(0, 5).map((o) => (
              <tr key={o.ip}>
                <td style={{ fontFamily: 'monospace' }}>{o.ip}</td>
                <td style={{ color: '#ef4444', fontWeight: 700 }}>{o.attempts}</td>
                <td>{o.services.join(', ')}</td>
                <td>{new Date(o.last_seen * 1000).toLocaleTimeString()}</td>
                <td>
                  <button
                    onClick={() => blockIP(o.ip, 'Top brute force offender')}
                    style={{ background: '#7f1d1d', color: '#fca5a5', border: '1px solid #ef4444', borderRadius: 6, padding: '3px 10px', cursor: 'pointer', fontSize: 12 }}
                  >
                    Block
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* IP BLOCKING SECTION */}
      <div className="card" style={{ marginTop: 12 }}>
        <h3>🚫 IP Blocking</h3>

        <div className="toolbar" style={{ marginBottom: 12 }}>
          <input
            placeholder="e.g. 192.168.1.42"
            value={manualIp}
            onChange={(e) => setManualIp(e.target.value)}
            style={{ minWidth: 200 }}
          />
          <input
            placeholder="Reason (optional)"
            value={reason}
            onChange={(e) => setReason(e.target.value)}
            style={{ minWidth: 240 }}
          />
          <button
            onClick={handleManualBlock}
            style={{
              background: '#7f1d1d', color: '#fca5a5',
              border: '1px solid #ef4444', borderRadius: 8,
              padding: '7px 16px', cursor: 'pointer', fontWeight: 700,
            }}
          >
            Block IP
          </button>
        </div>

        <table className="talkers">
          <thead>
            <tr><th>IP Address</th><th>Reason</th><th>By</th><th>Blocked At</th><th>Action</th></tr>
          </thead>
          <tbody>
            {blocked.length === 0 && (
              <tr><td colSpan={5} style={{ color: '#8b98b4' }}>No IPs blocked yet.</td></tr>
            )}
            {blocked.map((b) => (
              <tr key={b.ip_address}>
                <td style={{ fontFamily: 'monospace' }}>{b.ip_address}</td>
                <td>{b.reason || '—'}</td>
                <td>
                  <span className={b.blocked_by === 'auto' ? 'sev HIGH' : 'sev MEDIUM'}>
                    {b.blocked_by}
                  </span>
                </td>
                <td>{new Date(b.blocked_at * 1000).toLocaleString()}</td>
                <td>
                  <button
                    onClick={() => unblockIP(b.ip_address)}
                    style={{
                      background: '#052e16', color: '#86efac',
                      border: '1px solid #22c55e', borderRadius: 6,
                      padding: '3px 10px', cursor: 'pointer', fontSize: 12,
                    }}
                  >
                    Unblock
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
