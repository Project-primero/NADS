import { useEffect, useState } from 'react';

const API = 'http://127.0.0.1:8000/api';

export interface RateRow {
  ip: string; attempts: number; rate_per_sec: number;
  first_seen: number; last_seen: number;
}
export interface RotationRow {
  username: string; unique_ips: number; total_attempts: number; ips: string[];
}
export interface OffenderRow {
  ip: string; attempts: number; last_seen: number; services: string[];
}
export interface BlockedRow {
  ip_address: string; reason: string; blocked_at: number; blocked_by: string;
}
export interface Summary {
  total_events: number; last_5min: number;
  unique_attackers: number; unique_targets: number;
}
export interface ServiceCounts {
  SSH: number; FTP: number; RDP: number;
  Telnet: number; HTTP: number; Spraying: number;
}
export interface TimelineRow {
  ts: number;
  SSH: number; FTP: number; RDP: number;
  Telnet: number; HTTP: number; Spraying: number;
}

export function useBruteForce(pollMs = 5000) {
  const [summary, setSummary] = useState<Summary | null>(null);
  const [byService, setByService] = useState<ServiceCounts | null>(null);
  const [rates, setRates] = useState<RateRow[]>([]);
  const [rotations, setRotations] = useState<RotationRow[]>([]);
  const [offenders, setOffenders] = useState<OffenderRow[]>([]);
  const [timeline, setTimeline] = useState<TimelineRow[]>([]);
  const [blocked, setBlocked] = useState<BlockedRow[]>([]);

  const fetchAll = async () => {
    try {
      const [s, svc, r, v, o, t, b] = await Promise.all([
        fetch(`${API}/brute-force/summary`).then((x) => x.json()),
        fetch(`${API}/brute-force/by-service`).then((x) => x.json()),
        fetch(`${API}/brute-force/rates`).then((x) => x.json()),
        fetch(`${API}/brute-force/vpn-rotation`).then((x) => x.json()),
        fetch(`${API}/brute-force/top-offenders`).then((x) => x.json()),
        fetch(`${API}/brute-force/timeline`).then((x) => x.json()),
        fetch(`${API}/blocked-ips`).then((x) => x.json()),
      ]);
      setSummary(s);
      setByService(svc);
      setRates(r.rates ?? []);
      setRotations(v.rotations ?? []);
      setOffenders(o.offenders ?? []);
      setTimeline(t.timeline ?? []);
      setBlocked(b.blocked ?? []);
    } catch {
      /* offline */
    }
  };

  const blockIP = async (ip: string, reason: string) => {
    await fetch(`${API}/blocked-ips/block`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ip, reason }),
    });
    fetchAll();
  };

  const unblockIP = async (ip: string) => {
    await fetch(`${API}/blocked-ips/unblock`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ip }),
    });
    fetchAll();
  };

  useEffect(() => {
    fetchAll();
    const t = setInterval(fetchAll, pollMs);
    return () => clearInterval(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [pollMs]);

  return { summary, byService, rates, rotations, offenders, timeline, blocked, blockIP, unblockIP, refresh: fetchAll };
}
