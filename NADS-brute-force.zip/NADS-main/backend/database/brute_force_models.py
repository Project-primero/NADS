"""Brute force & IP blocking database models."""
from sqlalchemy import Column, Integer, String, Float
from backend.database.models import Base


class BlockedIP(Base):
    __tablename__ = "blocked_ips"
    id = Column(Integer, primary_key=True)
    ip_address = Column(String, unique=True, index=True)
    reason = Column(String, default="")
    blocked_at = Column(Float)
    blocked_by = Column(String, default="manual")


class BruteForceEvent(Base):
    __tablename__ = "brute_force_events"
    id = Column(Integer, primary_key=True)
    timestamp = Column(Float, index=True)
    src_ip = Column(String, index=True)
    username = Column(String, default="unknown")
    service = Column(String, default="")
    severity = Column(String, default="HIGH")
    attack_type = Column(String, default="")
