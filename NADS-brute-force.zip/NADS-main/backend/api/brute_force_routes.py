"""Brute force + IP blocking API routes."""
from fastapi import APIRouter
from pydantic import BaseModel

router = APIRouter()
_state: dict = {}


def init(state: dict):
    global _state
    _state = state


class BlockRequest(BaseModel):
    ip: str
    reason: str = ""


@router.get("/brute-force/summary")
def summary():
    bf = _state["brute_force"]
    bf.ingest_alerts()
    return bf.summary()


@router.get("/brute-force/by-service")
def by_service():
    bf = _state["brute_force"]
    bf.ingest_alerts()
    return bf.by_service()


@router.get("/brute-force/rates")
def rates(window: int = 60):
    bf = _state["brute_force"]
    bf.ingest_alerts()
    return {"rates": bf.rate_per_ip(window)}


@router.get("/brute-force/vpn-rotation")
def vpn_rotation(window: int = 600, min_ips: int = 3):
    bf = _state["brute_force"]
    bf.ingest_alerts()
    return {"rotations": bf.vpn_rotation(window, min_ips)}


@router.get("/brute-force/top-offenders")
def top_offenders(limit: int = 10):
    bf = _state["brute_force"]
    bf.ingest_alerts()
    return {"offenders": bf.top_offenders(limit)}


@router.get("/brute-force/timeline")
def timeline(window: int = 3600, bucket: int = 60):
    bf = _state["brute_force"]
    bf.ingest_alerts()
    return {"timeline": bf.timeline(window, bucket)}


@router.get("/blocked-ips")
def blocked_list():
    blocker = _state["ip_blocker"]
    return {"blocked": blocker.list_all()}


@router.post("/blocked-ips/block")
def block_ip(req: BlockRequest):
    blocker = _state["ip_blocker"]
    entry = blocker.block(req.ip, req.reason, by="manual")
    return {"ok": True, "entry": entry}


@router.post("/blocked-ips/unblock")
def unblock_ip(req: BlockRequest):
    blocker = _state["ip_blocker"]
    ok = blocker.unblock(req.ip)
    return {"ok": ok}
