"""Brute force analytics: rate limiting, VPN rotation, IP blocking."""
from __future__ import annotations
import time
from collections import defaultdict, deque


BRUTE_FORCE_TYPES = {
    "SSH Brute Force", "FTP Brute Force", "RDP Brute Force",
    "Telnet Brute Force", "HTTP Brute Force", "Password Spraying",
}


class BruteForceAnalyzer:
    """Reads alerts from AlertManager and produces enhanced analytics."""

    def __init__(self, alert_manager, db=None):
        self.alerts = alert_manager
        self.db = db
        self._events: deque = deque(maxlen=5000)
        self._seen_ids: set = set()

    def ingest_alerts(self) -> int:
        new = 0
        for a in self.alerts.history:
            aid = a.get("id")
            if aid in self._seen_ids:
                continue
            if a.get("attack_type") not in BRUTE_FORCE_TYPES:
                continue
            self._seen_ids.add(aid)
            self._events.append({
                "timestamp": a.get("timestamp", time.time()),
                "src_ip": a.get("src_ip", "?"),
                "dst_ip": a.get("dst_ip", "?"),
                "service": self._service_from_type(a.get("attack_type", "")),
                "attack_type": a.get("attack_type", ""),
                "severity": a.get("severity", "HIGH"),
                "username": a.get("username", "unknown"),
            })
            new += 1
        return new

    @staticmethod
    def _service_from_type(atype: str) -> str:
        for svc in ("SSH", "FTP", "RDP", "Telnet", "HTTP"):
            if svc in atype:
                return svc
        if "Spraying" in atype:
            return "Multiple"
        return "Unknown"

    def by_service(self, window_sec: int = 3600) -> dict:
        cutoff = time.time() - window_sec
        counts: dict[str, int] = defaultdict(int)
        for e in self._events:
            if e["timestamp"] >= cutoff:
                counts[e["service"]] += 1
        return {
            "SSH": counts.get("SSH", 0),
            "FTP": counts.get("FTP", 0),
            "RDP": counts.get("RDP", 0),
            "Telnet": counts.get("Telnet", 0),
            "HTTP": counts.get("HTTP", 0),
            "Spraying": counts.get("Multiple", 0),
        }

    def rate_per_ip(self, window_sec: int = 60) -> list[dict]:
        cutoff = time.time() - window_sec
        buckets: dict[str, deque] = defaultdict(deque)
        for e in self._events:
            if e["timestamp"] >= cutoff:
                buckets[e["src_ip"]].append(e["timestamp"])
        out = []
        for ip, times in buckets.items():
            if len(times) < 2:
                continue
            span = max(times) - min(times) or 1
            out.append({
                "ip": ip,
                "attempts": len(times),
                "rate_per_sec": round(len(times) / max(span, 1), 3),
                "first_seen": min(times),
                "last_seen": max(times),
            })
        return sorted(out, key=lambda x: x["attempts"], reverse=True)

    def vpn_rotation(self, window_sec: int = 600, min_ips: int = 3) -> list[dict]:
        cutoff = time.time() - window_sec
        by_user: dict[str, set] = defaultdict(set)
        counts: dict[str, int] = defaultdict(int)
        for e in self._events:
            if e["timestamp"] < cutoff:
                continue
            by_user[e["username"]].add(e["src_ip"])
            counts[e["username"]] += 1
        out = []
        for user, ips in by_user.items():
            if len(ips) >= min_ips:
                out.append({
                    "username": user,
                    "unique_ips": len(ips),
                    "total_attempts": counts[user],
                    "ips": sorted(ips)[:10],
                })
        return sorted(out, key=lambda x: x["unique_ips"], reverse=True)

    def top_offenders(self, limit: int = 10) -> list[dict]:
        counts: dict[str, dict] = defaultdict(
            lambda: {"attempts": 0, "last_seen": 0, "services": set()})
        for e in self._events:
            c = counts[e["src_ip"]]
            c["attempts"] += 1
            c["last_seen"] = max(c["last_seen"], e["timestamp"])
            c["services"].add(e["service"])
        out = [
            {"ip": ip, "attempts": v["attempts"], "last_seen": v["last_seen"],
             "services": sorted(v["services"])}
            for ip, v in counts.items()
        ]
        return sorted(out, key=lambda x: x["attempts"], reverse=True)[:limit]

    def timeline(self, window_sec: int = 3600, bucket_sec: int = 60) -> list[dict]:
        now = int(time.time() // bucket_sec) * bucket_sec
        start = now - (window_sec // bucket_sec) * bucket_sec

        buckets: dict[int, dict] = {}
        b = start
        while b <= now:
            buckets[b] = {"SSH": 0, "FTP": 0, "RDP": 0, "Telnet": 0,
                          "HTTP": 0, "Spraying": 0}
            b += bucket_sec

        for e in self._events:
            if e["timestamp"] < start:
                continue
            bucket = int(e["timestamp"] // bucket_sec) * bucket_sec
            if bucket in buckets:
                svc = e["service"]
                if svc == "Multiple":
                    svc = "Spraying"
                if svc in buckets[bucket]:
                    buckets[bucket][svc] += 1

        out = []
        for b in sorted(buckets):
            row = {"ts": b, **buckets[b]}
            out.append(row)
        return out
    def auto_block_check(self, blocker, threshold: int = 5,
                         window_sec: int = 600) -> list[str]:
        """Auto-block any IP exceeding threshold. Uses TOTAL attempts."""
        total_counts: dict[str, int] = defaultdict(int)
        for e in self._events:
            total_counts[e["src_ip"]] += 1
        newly = []
        for ip, n in total_counts.items():
            if n >= threshold and not blocker.is_blocked(ip):
                blocker.block(ip, f"Auto: {n} total attempts", by="auto")
                newly.append(ip)
        return newly

    def summary(self) -> dict:
        now = time.time()
        last_5min = [e for e in self._events if e["timestamp"] >= now - 300]
        return {
            "total_events": len(self._events),
            "last_5min": len(last_5min),
            "unique_attackers": len({e["src_ip"] for e in self._events}),
            "unique_targets": len({e["username"] for e in self._events}),
        }


class IPBlocker:
    """Manage blocked IP list — persistent via DB, cached in memory."""

    def __init__(self, db=None):
        self.db = db
        self._blocked: dict[str, dict] = {}

    def load(self):
        if not self.db or not hasattr(self.db, "get_blocked_ips"):
            return
        try:
            for row in self.db.get_blocked_ips():
                self._blocked[row["ip_address"]] = row
        except Exception:
            pass

    def block(self, ip: str, reason: str = "", by: str = "manual") -> dict:
        entry = {
            "ip_address": ip,
            "reason": reason,
            "blocked_at": time.time(),
            "blocked_by": by,
        }
        self._blocked[ip] = entry
        if self.db and hasattr(self.db, "save_blocked_ip"):
            try:
                self.db.save_blocked_ip(entry)
            except Exception:
                pass
        return entry

    def unblock(self, ip: str) -> bool:
        if ip in self._blocked:
            del self._blocked[ip]
            if self.db and hasattr(self.db, "delete_blocked_ip"):
                try:
                    self.db.delete_blocked_ip(ip)
                except Exception:
                    pass
            return True
        return False

    def is_blocked(self, ip: str) -> bool:
        return ip in self._blocked

    def list_all(self) -> list[dict]:
        return sorted(self._blocked.values(),
                      key=lambda x: x.get("blocked_at", 0), reverse=True)
