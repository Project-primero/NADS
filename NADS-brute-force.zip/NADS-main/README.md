# 🛡️ Aegis — Network Anomaly Detection

Real-time SOC system: **capture → flow features → 30 signature detectors ⊕ ML → correlated alerts → live dashboard.**

---

## 🆕 What's New — Brute Force Command Center

This fork adds a dedicated **Brute Force** tab with:

- **6 KPI Cards** — SSH, FTP, RDP, Telnet, HTTP, Password Spraying counts
- **Wave Timeline** — Recharts area chart, same style as throughput
- **Live Rate Per IP** — attempts/second per attacker (60s window)
- **VPN / IP Rotation** — catches same user from 3+ IPs
- **Top Offenders** — highest-attack IPs
- **IP Blocking** — manual + auto-block (5+ attempts → blocked)
- **9 new REST endpoints** under `/api/brute-force/*` and `/api/blocked-ips/*`

---

## 🔄 How It Differs From the Original

| Feature | Original | This Fork |
|---------|----------|-----------|
| Brute force display | One panel | Dedicated tab |
| IP blocking | ❌ | ✅ Manual + auto |
| Rate limiting | ❌ | ✅ Live per-IP |
| VPN rotation detection | ❌ | ✅ Yes |
| Persistence | Alerts only | + `blocked_ips` table |
| Auto-response | ❌ | ✅ Auto-block |

**All original detection is untouched** — 30 detectors, ML models, and existing tabs work the same. This fork only **adds** the Brute Force tab.

---

## 🚀 How to Run

### Requirements
- Python 3.10+ · Node.js 18+ · npm 9+ · Git

### 1. Clone
```bash
git clone https://github.com/YOUR_USERNAME/NADS-brute-force.git
cd NADS-brute-force
```

### 2. Backend Setup
```bash
python3 -m venv /tmp/nadvenv
source /tmp/nadvenv/bin/activate
pip install -r requirements.txt
```

### 3. Frontend Setup
```bash
cd frontend && npm install && cd ..
```

### 4. Train Model (first run only)
```bash
python3 train_model.py
```

### 5. Run — Two Terminals

**Terminal 1 — Backend:**
```bash
source /tmp/nadvenv/bin/activate
make run
```
Wait for: `Uvicorn running on http://127.0.0.1:8000`

**Terminal 2 — Frontend:**
```bash
make run-frontend
```
Wait for: `VITE ready`

### 6. Open Browser 
```
http://localhost:5173
```
Click **🔐 Brute Force** in the sidebar.

---

## 🧪 Test It

1. Open Brute Force tab
2. Wait 30–60s for simulated attacks
3. IPs appear in **Top Offenders**
4. IPs with 5+ attempts auto-appear in **Blocked IPs** (`By: auto`)
5. Try manual block: type an IP + reason → **Block IP**

**API check:**
```bash
curl http://127.0.0.1:8000/api/brute-force/summary
curl http://127.0.0.1:8000/api/blocked-ips
```
Interactive docs: `http://127.0.0.1:8000/docs`

---

## 📡 New API Endpoints

| Method | Endpoint | Purpose |
|--------|----------|---------|
| GET | `/api/brute-force/summary` | Total events, attackers, targets |
| GET | `/api/brute-force/by-service` | Counts per service |
| GET | `/api/brute-force/rates` | Per-IP rate (60s) |
| GET | `/api/brute-force/vpn-rotation` | Same user, 3+ IPs |
| GET | `/api/brute-force/top-offenders` | Top attacking IPs |
| GET | `/api/brute-force/timeline` | Per-minute buckets |
| GET | `/api/blocked-ips` | All blocked IPs |
| POST | `/api/blocked-ips/block` | Block an IP |
| POST | `/api/blocked-ips/unblock` | Unblock an IP |

---

## 📁 New / Edited Files

```
backend/
  api/brute_force_routes.py          ⭐ NEW
  detection/brute_force_enhanced.py  ⭐ NEW
  database/brute_force_models.py     ⭐ NEW
  database/db.py                     ✏️ edited
  main.py                            ✏️ edited

frontend/src/
  components/BruteForceTab.tsx       ⭐ NEW
  components/Dashboard.tsx           ✏️ edited
  hooks/useBruteForce.ts             ⭐ NEW

README.md                            ✏️ updated
```

---

## 🛠️ Troubleshooting

| Problem | Fix |
|---------|-----|
| `vite: not found` | `cd frontend && npm install` |
| `/tmp/nadvenv` missing | Recreate venv (Step 2) |
| `CONNECTING…` forever | Backend not running — check `curl http://127.0.0.1:8000/api/stats` |
| Network tab blank | Hard refresh `Ctrl+Shift+R` |
| `ECONNREFUSED` | Backend is down. Run `make run` |

---



**Brute Force Command Center** by [Natnael] · Original Aegis by [Derege]
